This is a 'Repository' that having some good information about how "Weather App works".

Using "PYTHON" and "HTML".

Here are some informations Requirements--->

1.) Version.

2.) bs4.

3.) Requests.

4.) Pillow.

5.) tkinter.

6.) urllib request.

Cities--> In this we can see any city we want.

Application used for making weather app-->  By Open Weather API

This App provides us-->

1.) Humidity.

2.) Temperature.

3.) Pressure.

4.) Visibility.

5.) Speed--> tells us about at which speed the wind is blowing.

And many more......

Hope you like it and guide me if some changes are required.


_____________THANK YOU FOR VISIT_______________

             ____HAVE A GOOD DAY____
  
